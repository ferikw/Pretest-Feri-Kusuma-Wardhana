package com.example.feri_pretest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
