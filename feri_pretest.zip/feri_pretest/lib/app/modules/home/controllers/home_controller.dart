import 'package:get/get.dart';
import 'package:feri_pretest/app/modules/home/models/user_models.dart';
import 'package:feri_pretest/app/modules/home/providers/user_provider.dart';

class HomeController extends GetxController {
  var users = UserModel().obs;
  var isLoading = true.obs;
  var errorMessage = ''.obs;

  @override
  void onInit() {
    super.onInit();
    fetchUsers();
  }

  void fetchUsers() async {
    try {
      isLoading(true);
      var data = await UserProviders().getUsers();
      users(data);
    } catch (e) {
      errorMessage('Failed to load data');
    } finally {
      isLoading(false);
    }
  }

  @override
  void onClose() {
    super.onClose();
  }
}
