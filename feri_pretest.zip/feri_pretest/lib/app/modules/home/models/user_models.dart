class UserModel {
  List<User>? users;

  UserModel({this.users});

  UserModel.fromJson(Map<String, dynamic> json) {
    if (json['results'] != null) {
      users = <User>[];
      json['results'].forEach((v) {
        users!.add(User.fromJson(v));
      });
    }
  }
}

class User {
  String? firstName;
  String? lastName;
  String? city;
  String? country;
  String? imageUrl;
  String? gender;

  User({
    this.firstName,
    this.lastName,
    this.city,
    this.country,
    this.imageUrl,
    this.gender,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      firstName: json['name']['first'],
      lastName: json['name']['last'],
      city: json['location']['city'],
      country: json['location']['country'],
      imageUrl: json['picture']['large'],
      gender: json['gender'],
    );
  }
}
