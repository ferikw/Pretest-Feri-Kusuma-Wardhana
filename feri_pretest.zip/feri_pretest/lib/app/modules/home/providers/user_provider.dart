import 'package:feri_pretest/app/modules/home/models/user_models.dart';
import 'package:get/get.dart';

class UserProviders extends GetConnect {
  Future<UserModel> getUsers() async {
    final response = await get('https://randomuser.me/api/');
    if (response.status.hasError) {
      return Future.error(response.statusText!);
    } else {
      try {
        return UserModel.fromJson(response.body as Map<String, dynamic>);
      } catch (e) {
        return Future.error("Failed to parse response");
      }
    }
  }
}
