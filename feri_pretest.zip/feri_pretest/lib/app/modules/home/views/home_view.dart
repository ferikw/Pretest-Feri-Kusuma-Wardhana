import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:feri_pretest/app/modules/home/controllers/home_controller.dart';

class HomeView extends StatelessWidget {
  final HomeController controller = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Profile',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.green,
      ),
      backgroundColor: Colors.blueGrey.shade50,
      body: Obx(
        () {
          if (controller.isLoading.value) {
            return Center(child: CircularProgressIndicator());
          } else if (controller.errorMessage.isNotEmpty) {
            return Center(child: Text(controller.errorMessage.value));
          } else {
            final user = controller.users.value.users?[0];
            return SingleChildScrollView(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            radius: 70,
                            backgroundImage: NetworkImage(user?.imageUrl ?? ''),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      _buildDetailRow(
                        title: 'Nama Depan',
                        value: user?.firstName ?? '',
                        description: 'Nama depan',
                      ),
                      const SizedBox(height: 10),
                      _buildDetailRow(
                        title: 'Nama Belakang',
                        value: user?.lastName ?? '',
                        description: 'Nama belakang',
                      ),
                      const SizedBox(height: 10),
                      _buildDetailRow(
                        title: 'Kota',
                        value: user?.city ?? '',
                        description: 'Kota tempat tinggal',
                      ),
                      const SizedBox(height: 10),
                      _buildDetailRow(
                        title: 'Negara',
                        value: user?.country ?? '',
                        description: 'Negara tempat tinggal',
                      ),
                      const SizedBox(height: 10),
                      _buildDetailRow(
                        title: 'Gender',
                        value: user?.gender ?? '',
                        description: 'Jenis kelamin',
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            );
          }
        },
      ),
    );
  }

  Widget _buildDetailRow({
    required String title,
    required String value,
    required String description,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Colors.grey.shade400,
            width: 1,
          ),
        ),
      ),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 5),
          Text(
            value,
            style: const TextStyle(fontSize: 18, color: Colors.indigo),
          ),
          const SizedBox(height: 5),
          Text(
            description,
            style: const TextStyle(fontSize: 14, color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
